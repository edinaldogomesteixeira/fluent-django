let activeSubtitle = null;
let allData = {};
let vocabularyData = {};

function createVideoCard(video) {

    return `
    
        <div class="video-card">

            <div class="thumbnail">

                <img
                    src="${video.image}"
                    alt="${video.title}"
                    class="thumbnail-image"
                >

                <img
                    src="${video.preview}"
                    alt="${video.title}"
                    class="preview-image"
                >

            </div>

            <h3 class="video-title">
                ${video.title}
            </h3>

            <p class="video-info">
                ${video.level} • ${video.words} Words
            </p>

        </div>

    `;
}
function renderVideos(videos, containerId) {

    const container =
        document.getElementById(containerId);

    container.innerHTML = '';

    videos.forEach(video => {

        container.innerHTML +=
            createVideoCard(video);

    });
}

function setupSearch() {

    const searchInput =
        document.getElementById('searchInput');

    searchInput.addEventListener('input', () => {

        const value =
            searchInput.value.toLowerCase();

        const filteredRecent =
            allData.recentVideos.filter(video => {

                return video.title
                    .toLowerCase()
                    .includes(value);

            });

        const filteredTrending =
            allData.trendingVideos.filter(video => {

                return video.title
                    .toLowerCase()
                    .includes(value);

            });

        renderVideos(
            filteredRecent,
            'recentVideos'
        );

        renderVideos(
            filteredTrending,
            'trendingVideos'
        );

        /*setupPreviewVideos();*/
        setupVideoClicks();

    });

}

async function loadVideos() {

    const response =
        await fetch('./assets/data/videos.json');

    const data =
        await response.json();

    allData = data;

    renderVideos(
        data.recentVideos,
        'recentVideos'
    );

    renderVideos(
        data.trendingVideos,
        'trendingVideos'
    );

    setupSearch();
    /*setupPreviewVideos();*/
    setupVideoClicks();
    loadVocabulary();
}


loadVideos();
MediaController.init(
    document.getElementById(
        'modalVideo'
    )
);

function openModal(video) {

    const modal =
        document.getElementById('videoModal');
    
    if (video.provider === 'youtube') {

        const waitApi = setInterval(() => {

            if (window.youtubeAPIReady) {

                clearInterval(waitApi);

                MediaController.load(video);

            }

        }, 200);

    } else {

        MediaController.load(video);

    }

    document.getElementById('modalTitle')
        .innerText = video.title;

    document.getElementById('modalDetails')
        .innerText =
            `${video.level} • ${video.words} Words`;

    modal.classList.add('active');
    setupSubtitleSync();
    loadSubtitles(video);
}

function closeModal() {

    activeSubtitle = null;

    const modal =
        document.getElementById('videoModal');

    modal.classList.remove('active');

    MediaController.destroy();

    document.getElementById(
        'transcript'
    ).innerHTML = '';

    closeVocabularyPopup();
}

document
    .getElementById('closeModal')
    .addEventListener('click', closeModal);

document
    .getElementById('videoModal')
    .addEventListener('click', (event) => {

        if (
            event.target.id === 'videoModal'
        ) {
            closeModal();
        }

    });


function setupVideoClicks() {

    const cards =
        document.querySelectorAll('.video-card');

    cards.forEach(card => {

        card.addEventListener('click', () => {

            const title =
                card.querySelector('.video-title')
                    .innerText;

            let selectedVideo = null;

            const allVideos = [
                ...allData.recentVideos,
                ...allData.trendingVideos
            ];

            selectedVideo = allVideos.find(video => {

                return video.title === title;

            });

            if (selectedVideo) {

                openModal(selectedVideo);

            }

        });

    });

}

async function loadSubtitles(video) {

    const response =
        await fetch(video.subtitles);

    const subtitles =
        await response.json();

    const transcript =
        document.getElementById('transcript');

    transcript.innerHTML = '';

    subtitles.forEach(subtitle => {

        const words =
            subtitle.text.split(' ');

        const wordsHTML =
            words.map(word => {

                return `
                
                    <span class="word">
                        ${word}
                    </span>
                
                `;

            }).join('');

        transcript.innerHTML += `
                
            <div 
                class="subtitle-line"
                data-start="${subtitle.start}"
                data-end="${subtitle.end}"
            >
                ${wordsHTML}
            </div>

        `;

    });

    const subtitleLines =
        document.querySelectorAll('.subtitle-line');

    subtitleLines.forEach(line => {

        line.addEventListener('click', () => {

            const videoElement =
                document.getElementById('modalVideo');

            const start =
                Number(line.dataset.start);

            MediaController.seek(start);
            MediaController.play();

        });

    });

    /* WORD CLICKS */
    const words =
        document.querySelectorAll('.word');

    words.forEach(wordElement => {

        wordElement.addEventListener('click', (event) => {

            event.stopPropagation();

            const word =
                wordElement.innerText;

            openVocabularyPopup(word);

        });

    });
}

function setupSubtitleSync() {
    console.log('SYNC STARTED');

    const video =
        document.getElementById('modalVideo');
    
    video.ontimeupdate = null;
    video.addEventListener('timeupdate', () => {

        const currentTime =
             MediaController.getCurrentTime();
        
        console.log(currentTime);

        const subtitleLines =
            document.querySelectorAll('.subtitle-line');

        subtitleLines.forEach(line => {

            const start =
                parseFloat(
                    line.dataset.start
                );

            const end =
                parseFloat(
                    line.dataset.end
                );

            const isActive =

                currentTime >= start &&
                currentTime <= end;

            if (isActive) {

                if (activeSubtitle !== line) {

                    if (activeSubtitle) {

                        activeSubtitle.classList.remove(
                            'active'
                        );

                    }

                    activeSubtitle = line;

                    line.classList.add(
                        'active'
                    );

                    line.scrollIntoView({

                        behavior: 'smooth',

                        block: 'center'

                    });

                }

            } else {

                line.classList.remove(
                    'active'
                );

            }

        });

    });

}

async function loadVocabulary() {

    const response =
        await fetch('./assets/data/vocabulary.json');

    vocabularyData =
        await response.json();

}

function openVocabularyPopup(word) {

    const cleanWord =
        word
            .trim()
            .toLowerCase()
            .replace(/[^a-zA-Z']/g, '');

    console.log(
        'Clicked word:',
        cleanWord
    );

    const vocab =
        vocabularyData[cleanWord];

    if (!vocab) {

        closeVocabularyPopup();

        return;
    }

    const popup =
        document.getElementById('vocabPopup');

    document.getElementById('popupWord')
        .innerText = word;

    document.getElementById('popupIPA')
        .innerText = vocab.ipa;

    document.getElementById('popupTranslation')
        .innerText = vocab.translation;

    document.getElementById('popupDefinition')
        .innerText = vocab.definition;

    popup.classList.remove('active');

    setTimeout(() => {

        popup.classList.add('active');

    }, 10);

}

function closeVocabularyPopup() {

    document
        .getElementById('vocabPopup')
        .classList.remove('active');

}

document.addEventListener('click', (event) => {

    const popup =
        document.getElementById('vocabPopup');

    if (
        !popup.contains(event.target) &&
        !event.target.classList.contains('word')
    ) {

        closeVocabularyPopup();

    }

});