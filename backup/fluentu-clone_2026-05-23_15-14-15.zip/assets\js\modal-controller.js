let activeSubtitle = null;
let vocabularyData = {};

function initModalController() {

    MediaController.init(
        document.getElementById(
            'modalVideo'
        )
    );

    document
        .getElementById('closeModal')
        .addEventListener(
            'click',
            closeModal
        );

    document
        .getElementById('videoModal')
        .addEventListener(
            'click',
            (event) => {

                if (
                    event.target.id ===
                    'videoModal'
                ) {

                    closeModal();

                }

            }
        );

}

function openModal(video) {

    const modal =
        document.getElementById('videoModal');
    
    if (video.provider === 'youtube') {

        const waitApi = setInterval(() => {

            if (window.youtubeAPIReady) {

                clearInterval(waitApi);

                MediaController.load(video);

            }

        }, 200);

    } else {

        MediaController.load(video);

    }

    document.getElementById('modalTitle')
        .innerText = video.title;

    document.getElementById('modalDetails')
        .innerText =
            `${video.level} • ${video.words} Words`;

    modal.classList.add('active');
    setupSubtitleSync();
    loadSubtitles(video);
}

function closeModal() {

    activeSubtitle = null;

    const modal =
        document.getElementById('videoModal');

    modal.classList.remove('active');

    MediaController.destroy();

    document.getElementById(
        'transcript'
    ).innerHTML = '';

    closeVocabularyPopup();
}

async function loadSubtitles(video) {

    const response =
        await fetch(video.subtitles);

    const subtitles =
        await response.json();

    const transcript =
        document.getElementById('transcript');

    transcript.innerHTML = '';

    subtitles.forEach(subtitle => {

        const words =
            subtitle.text.split(' ');

        const wordsHTML =
            words.map(word => {

                return `
                
                    <span class="word">
                        ${word}
                    </span>
                
                `;

            }).join('');

        transcript.innerHTML += `
                
            <div 
                class="subtitle-line"
                data-start="${subtitle.start}"
                data-end="${subtitle.end}"
            >
                ${wordsHTML}
            </div>

        `;

    });

    const subtitleLines =
        document.querySelectorAll('.subtitle-line');

    subtitleLines.forEach(line => {

        line.addEventListener('click', () => {

            const videoElement =
                document.getElementById('modalVideo');

            const start =
                Number(line.dataset.start);

            MediaController.seek(start);
            MediaController.play();

        });

    });

    /* WORD CLICKS */
    const words =
        document.querySelectorAll('.word');

    words.forEach(wordElement => {

        wordElement.addEventListener('click', (event) => {

            event.stopPropagation();

            const word =
                wordElement.innerText;

            openVocabularyPopup(
                word,
                wordElement
            );

        });

    });
}

function setupSubtitleSync() {
    //console.log('SYNC STARTED');

    const video =
        document.getElementById('modalVideo');
    
    video.ontimeupdate = null;
    video.addEventListener('timeupdate', () => {

        const currentTime =
             MediaController.getCurrentTime();
        
        //console.log(currentTime);

        const subtitleLines =
            document.querySelectorAll('.subtitle-line');

        subtitleLines.forEach(line => {

            const start =
                parseFloat(
                    line.dataset.start
                );

            const end =
                parseFloat(
                    line.dataset.end
                );

            const isActive =

                currentTime >= start &&
                currentTime <= end;

            if (isActive) {

                if (activeSubtitle !== line) {

                    if (activeSubtitle) {

                        activeSubtitle.classList.remove(
                            'active'
                        );

                    }

                    activeSubtitle = line;

                    line.classList.add(
                        'active'
                    );

                    line.scrollIntoView({

                        behavior: 'smooth',

                        block: 'center'

                    });

                }

            } else {

                line.classList.remove(
                    'active'
                );

            }

        });

    });

}

async function loadVocabulary() {

     const response =
        await fetch(
            './data/vocabulary.json'
        );

    vocabularyData =
        await response.json();
    
    console.log(vocabularyData);

}

function openVocabularyPopup(
    word,
    element
) {

    const popup =
        document.getElementById(
            'vocabPopup'
        );

    /* CLEAN WORD */

    const cleanWord =

        word
            .toLowerCase()
            .trim()
            .replace(/[.,!?;:]/g, '');

    /* FIND DATA */

    const data =
        vocabularyData[
            cleanWord
        ];

    if (!data) {

        console.log(
            'Word not found:',
            cleanWord
        );

        return;
    }

    /* CONTENT */

    document.getElementById(
        'popupWord'
    ).innerText = cleanWord;

    document.getElementById(
        'popupIPA'
    ).innerText =
        data.ipa || '';

    document.getElementById(
        'popupTranslation'
    ).innerText =
        data.translation || '';

    document.getElementById(
        'popupDefinition'
    ).innerText =
        data.definition || '';

    /* SHOW */

    popup.classList.add(
        'active'
    );

    /* POSITION */

    const rect =
        element.getBoundingClientRect();

    const popupWidth =
        popup.offsetWidth;

    const popupHeight =
        popup.offsetHeight;

    let leftPosition =

        rect.left +
        window.scrollX +
        rect.width / 2 -
        popupWidth / 2;

    /* LIMIT SCREEN */

    if (leftPosition < 16) {

        leftPosition = 16;
    }

    if (
        leftPosition + popupWidth >
        window.innerWidth - 16
    ) {

        leftPosition =
            window.innerWidth -
            popupWidth -
            16;
    }

    popup.style.left =
        `${leftPosition}px`;

    popup.style.top = `${
        rect.top +
        window.scrollY -
        popupHeight -
        12
    }px`;
}

function closeVocabularyPopup() {

    document
        .getElementById('vocabPopup')
        .classList.remove('active');

}

document.addEventListener('click', (event) => {

    const popup =
        document.getElementById('vocabPopup');

    if (
        !popup.contains(event.target) &&
        !event.target.classList.contains('word')
    ) {

        closeVocabularyPopup();

    }

});


document
    .getElementById('closeModal')
    .addEventListener('click', closeModal);

document
    .getElementById('videoModal')
    .addEventListener('click', (event) => {

        if (
            event.target.id === 'videoModal'
        ) {
            closeModal();
        }

    });


