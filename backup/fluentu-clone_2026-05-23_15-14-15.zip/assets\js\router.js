async function loadExplorePage() {

    const response =
        await fetch(
            './pages/explore.html'
        );

    const html =
        await response.text();

    document.getElementById(
        'mainContent'
    ).innerHTML = html;

    loadVideos();
}

async function loadTopicPage() {

    const response =
        await fetch(
            './pages/topic.html'
        );

    const html =
        await response.text();

    document.getElementById(
        'mainContent'
    ).innerHTML = html;
}

document.addEventListener(
    'click',
    async (event) => {

        const link =
            event.target.closest('a');

        if (!link) return;

        const href =
            link.getAttribute('href');

        if (!href) return;

        /* TOPIC */

        if (
            href.includes('topic.html')
        ) {

            event.preventDefault();

            const url =
                new URL(
                    href,
                    window.location.origin
                );

            const section =
                url.searchParams.get(
                    'section'
                );

            await openTopic(section);
        }

    }
);

async function loadSidebar() {

    const response =
        await fetch(
            './components/sidebar.html'
        );

    const html =
        await response.text();

    document.getElementById(
        'sidebarContainer'
    ).innerHTML = html;
}

async function loadTopbar() {

    const response =
        await fetch(
            './components/topbar.html'
        );

    const html =
        await response.text();

    document.getElementById(
        'topbarContainer'
    ).innerHTML = html;
}

async function loadModal() {

    const response =
        await fetch(
            './components/modal.html'
        );

    const html =
        await response.text();

    document.getElementById(
        'modalContainer'
    ).innerHTML = html;
}

async function loadVocabPopup() {

    const response =
        await fetch(
            './components/vocab-popup.html'
        );

    const html =
        await response.text();

    document.getElementById(
        'vocabPopupContainer'
    ).innerHTML = html;
}

window.addEventListener(
    'DOMContentLoaded',
    async () => {
        await loadTopbar();
        await loadSidebar();
        await loadModal();
        initModalController();
        await loadVocabulary();
        await loadVocabPopup();
        await loadExplorePage();
    }
);