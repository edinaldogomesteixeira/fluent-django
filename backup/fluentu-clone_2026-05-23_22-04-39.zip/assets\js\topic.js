const params =
    new URLSearchParams(
        window.location.search
    );

const section =
    params.get('section');

const topicTitle =
    document.getElementById(
        'topicTitle'
    );

const topicGrid =
    document.getElementById(
        'topicGrid'
    );

topicTitle.innerText =
    section;

fetch('./data/videos.json')

    .then(response => response.json())

    .then(videoData => {

        const videos =
            videoData[section];

        if (!videos) {

            topicGrid.innerHTML =
                'No videos found';

            return;
        }

        topicGrid.innerHTML =
            videos.map(video => {

                return `

                    <div class="video-card">

                        <div class="thumbnail">

                            <img
                                src="${video.image}"
                                class="thumbnail-image"
                            />

                        </div>

                        <h3 class="video-title">

                            ${video.title}

                        </h3>

                        <p class="video-info">

                            ${video.level}
                            •
                            ${video.words} Words

                        </p>

                    </div>

                `;

            }).join('');

    });