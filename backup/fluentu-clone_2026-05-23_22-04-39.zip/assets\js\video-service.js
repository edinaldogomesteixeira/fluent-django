let allData = {};

async function loadVideos() {

    const response =
        await fetch('./data/videos.json');

    const data =
        await response.json();

    allData = data;

    renderVideos(
        data.recentVideos,
        'recentVideos'
    );

    renderVideos(
        data.trendingVideos,
        'trendingVideos'
    );

    setupSearch();
    /*setupPreviewVideos();*/
    setupVideoClicks();
    loadVocabulary();
}
