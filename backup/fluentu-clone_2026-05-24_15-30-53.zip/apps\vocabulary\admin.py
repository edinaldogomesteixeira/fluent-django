from django.contrib import admin

from .models import (
    VocabularyWord,
    SubtitleWord
)


#admin.site.register(
#    VocabularyWord
#)

#admin.site.register(
#    SubtitleWord
#)

@admin.register(VocabularyWord)
class VocabularyWordAdmin(admin.ModelAdmin):

    list_display = (
        'id',
        'word',
        'normalized_word',
        'frequency_rank',
    )

    search_fields = (
        'word',
    )

    ordering = (
        'word',
    )

    list_per_page = 100


@admin.register(SubtitleWord)
class SubtitleWordAdmin(admin.ModelAdmin):

    list_display = (
        'id',
        'original_word',
        'vocabulary_word',
        'segment',
        'position',
    )

    search_fields = (
        'original_word',
    )

    list_filter = (
        'vocabulary_word',
    )

    ordering = (
        'segment',
        'position',
    )

    list_per_page = 100