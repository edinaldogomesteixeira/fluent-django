from django.db import models

from apps.subtitles.models import (
    SubtitleSegment
)


class VocabularyWord(models.Model):

    word = models.CharField(
        max_length=255,
        unique=True
    )

    normalized_word = models.CharField(
        max_length=255,
        unique=True,
        db_index=True
    )

    translation = models.CharField(
        max_length=255,
        blank=True,
        null=True
    )

    ipa = models.CharField(
        max_length=255,
        blank=True,
        null=True
    )

    frequency_rank = models.IntegerField(
        default=0
    )

    created_at = models.DateTimeField(
        auto_now_add=True
    )

    class Meta:

        ordering = ['word']

    def __str__(self):

        return self.word


class SubtitleWord(models.Model):

    segment = models.ForeignKey(

        SubtitleSegment,

        on_delete=models.CASCADE,

        related_name='subtitle_words'
    )

    vocabulary_word = models.ForeignKey(

        VocabularyWord,

        on_delete=models.CASCADE,

        related_name='subtitle_words'
    )

    original_word = models.CharField(
        max_length=255
    )

    position = models.IntegerField(
        default=0
    )

    created_at = models.DateTimeField(
        auto_now_add=True
    )

    class Meta:

        ordering = [

            'segment',
            'position'
        ]

        unique_together = (

            'segment',
            'position'
        )

    def __str__(self):

        return (

            f'{self.original_word} '
            f'({self.segment.id})'
        )