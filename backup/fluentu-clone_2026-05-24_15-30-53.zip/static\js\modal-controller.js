let activeSubtitle = null;
let vocabularyData = {};

function initModalController() {

    MediaController.init(
        document.getElementById(
            'modalVideo'
        )
    );

    document
        .getElementById('closeModal')
        .addEventListener(
            'click',
            closeModal
        );

    document
        .getElementById('videoModal')
        .addEventListener(
            'click',
            (event) => {

                if (
                    event.target.id ===
                    'videoModal'
                ) {

                    closeModal();

                }

            }
        );

}

function openModal(video) {

    const modal =
        document.getElementById('videoModal');
    
    if (video.provider === 'youtube') {

        const waitApi = setInterval(() => {

            if (window.youtubeAPIReady) {

                clearInterval(waitApi);

                MediaController.load(video);

            }

        }, 200);

    } else {

        MediaController.load(video);

    }

    document.getElementById('modalTitle')
        .innerText = video.title;

    document.getElementById('modalDetails')
        .innerText =
            `${video.level} • ${video.words} Words`;

    modal.classList.add('active');

    const modalContent =
        document.querySelector(
            '.modal-content'
        );

    modalContent.addEventListener(
        'click',
        (event) => {

            /* IGNORE WORD */
            console.log(
                'CLICK:',
                event.target
            );

            if (
                event.target.closest(
                    '.word'
                )
            ) {

                return;
            }

            closeVocabularyPopup();

        }
    );

    setupSubtitleSync();
    loadSubtitles(video);
}

function closeModal() {

    activeSubtitle = null;

    const modal =
        document.getElementById('videoModal');

    modal.classList.remove('active');

    MediaController.destroy();

    document.getElementById(
        'transcript'
    ).innerHTML = '';

    closeVocabularyPopup();
}

async function loadSubtitles(video) {

    if (!video.subtitles) {

        document.getElementById(
            'videoDialogue'
        ).innerHTML = `

            <div class="empty-message">

                No subtitles available.

            </div>

        `;

        return;
    }

    const response =
        await fetch(`/api/videos/${video.id}/subtitles/`)

    const subtitles =
        await response.json();

    const transcript =
        document.getElementById('transcript');

    transcript.innerHTML = '';

    subtitles.forEach(subtitle => {

        const words =
            subtitle.text.split(' ');

        const wordsHTML =
            words.map(word => {

                return `
                
                    <span class="word">
                        ${word}
                    </span>
                
                `;

            }).join('');

        transcript.innerHTML += `
                
            <div 
                class="subtitle-line"
                data-start="${subtitle.start}"
                data-end="${subtitle.end}"
            >
                ${wordsHTML}
            </div>

        `;

    });

    const subtitleLines =
        document.querySelectorAll('.subtitle-line');

    subtitleLines.forEach(line => {

        line.addEventListener('click', () => {

            const videoElement =
                document.getElementById('modalVideo');

            const start =
                Number(line.dataset.start);

            MediaController.seek(start);
            MediaController.play();

        });

    });

    /* WORD CLICKS */
    const words =
        document.querySelectorAll('.word');

    words.forEach(wordElement => {

        wordElement.addEventListener('click', (event) => {

            event.stopPropagation();

            const word =
                wordElement.innerText;

            const rect =
                wordElement.getBoundingClientRect();

            openVocabularyPopup(
                word,
                rect
            );

        });

    });
}

function setupSubtitleSync() {
    //console.log('SYNC STARTED');

    const video =
        document.getElementById('modalVideo');
    
    video.ontimeupdate = null;
    video.addEventListener('timeupdate', () => {

        const currentTime =
             MediaController.getCurrentTime();
        
        //console.log(currentTime);

        const subtitleLines =
            document.querySelectorAll('.subtitle-line');

        subtitleLines.forEach(line => {

            const start =
                parseFloat(
                    line.dataset.start
                );

            const end =
                parseFloat(
                    line.dataset.end
                );

            const isActive =

                currentTime >= start &&
                currentTime <= end;

            if (isActive) {

                if (activeSubtitle !== line) {

                    if (activeSubtitle) {

                        activeSubtitle.classList.remove(
                            'active'
                        );

                    }

                    activeSubtitle = line;

                    line.classList.add(
                        'active'
                    );

                    line.scrollIntoView({

                        behavior: 'smooth',

                        block: 'center'

                    });

                }

            } else {

                line.classList.remove(
                    'active'
                );

            }

        });

    });

}

async function loadVocabulary() {

     const response =
        await fetch(
            '/static/data/vocabulary.json'
        );

    vocabularyData =
        await response.json();
    
    console.log(vocabularyData);

}

function openVocabularyPopup(
    word,
    rect
) {

    const popup =
        document.getElementById(
            'vocabPopup'
        );

    const lookup =
        word
            .toLowerCase()
            .trim()
            .replace(/[.,!?]/g, '');

    popup.innerHTML = `
        <div style="
            
            background:white;
            color:black;
            font-size:24px;
            border-radius:20px;
        ">

            ${word}
            ${vocabularyData[lookup]?.ipa || ''}
            ${vocabularyData[lookup]?.translation || ''}
            ${vocabularyData[lookup]?.definition || ''}
            

        </div>
    `;

    popup.style.position =
        'fixed';

    let leftPosition =
        rect.left +
        rect.width / 2 -
        160;

    if (leftPosition < 16) {

        leftPosition = 16;
    }

    if (leftPosition > window.innerWidth - 336) {

        leftPosition =
            window.innerWidth - 336;
    }

    popup.style.left =
        `${leftPosition}px`;
    

    requestAnimationFrame(() => {

        const popupHeight =
            popup.offsetHeight;

        let topPosition =

            rect.top -
            popupHeight -
            18;

        if (topPosition < 16) {

            topPosition =
                rect.bottom + 18;
        }

        popup.style.top =
            `${topPosition}px`;

    });



    popup.style.zIndex =
        '999999';

    popup.style.display =
        'block';

    popup.classList.add(
        'active'
    );

}

function closeVocabularyPopup() {

    const popup =
        document.getElementById(
            'vocabPopup'
        );

    popup.classList.remove(
        'active'
    );

    setTimeout(() => {

        popup.style.display =
            'none';

    }, 180);

}

document.addEventListener(
    'pointerdown',
    (event) => {

        const popup =
            document.getElementById(
                'vocabPopup'
            );

        const clickedWord =

            event.target.closest(
                '.subtitle-word'
            );

        const clickedPopup =

            event.target.closest(
                '#vocabPopup'
            );

        /* KEEP OPEN */

        if (
            clickedWord ||
            clickedPopup
        ) {

            return;
        }

        closeVocabularyPopup();

    }
);

document
    .getElementById('closeModal')
    .addEventListener('click', closeModal);

document
    .getElementById('videoModal')
    .addEventListener('click', (event) => {

        if (
            event.target.id === 'videoModal'
        ) {
            closeModal();
        }

    });


