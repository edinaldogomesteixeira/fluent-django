async function loadExplorePage() {

    const response = await fetch('/explore/');

    const html =
        await response.text();

    document.getElementById(
        'mainContent'
    ).innerHTML = html;

    loadVideos();
}

async function loadTopicPage() {

    const response = await fetch('/topic/');

    const html =
        await response.text();

    document.getElementById(
        'mainContent'
    ).innerHTML = html;
}




/* YOUTUBE PLAYER */

function createYouTubePlayer(
    youtubeId
) {

    const youtubeContainer =
        document.getElementById(
            'youtubePlayer'
        );

    if (
        !youtubeContainer
    ) {

        console.error(
            'youtubePlayer container not found'
        );

        return;
    }

    /* DESTROY PREVIOUS */

    if (
        youtubePlayer
    ) {

        youtubePlayer.destroy();
    }

    youtubePlayer = new YT.Player(
        'youtubePlayer',
        {

            height: '500',

            width: '100%',

            videoId: youtubeId,

            playerVars: {

                autoplay: 1,

                controls: 1,

                rel: 0
            }
        }
    );
}

document.addEventListener(
    'click',
    async (event) => {

        const link =
            event.target.closest('a');

        if (!link) return;

        const href =
            link.getAttribute('href');

        if (!href) return;

        /* TOPIC */

        if (
            href.includes('topic.html')
        ) {

            event.preventDefault();

            const url =
                new URL(
                    href,
                    window.location.origin
                );

            const section =
                url.searchParams.get(
                    'section'
                );

            await openTopic(section);
        }

    }
);

function setupPlayVideo(video) {

    const videoElement =
        document.getElementById(
            'playVideo'
        );

    const youtubeContainer =
        document.getElementById(
            'youtubePlayer'
        );

    /* RESET */

    videoElement.style.display =
        'none';

    youtubeContainer.style.display =
        'none';

    /* YOUTUBE */

    if (
        video.provider === 'youtube'
    ) {

        youtubeContainer.style.display =
            'block';

        createYouTubePlayer(
            video.youtubeId
        );

        return;
    }

    /* MP4 / HLS */

    videoElement.style.display =
        'block';

    videoElement.src =
        video.video ||
        video.hls;
}


window.addEventListener(
    'DOMContentLoaded',
    async () => {
        
        
        
        initModalController();
        await loadVocabulary();
        
        await loadExplorePage();
    }
);

async function loadVideoPage() {

    const response =
        await fetch('/video/');

    const html =
        await response.text();

    document.getElementById(
        'mainContent'
    ).innerHTML = html;

}

async function openVideoPage(
    videoId
) {

    await loadVideoPage();

    const allVideos = [

        ...allData.recentVideos,

        ...allData.trendingVideos,

        ...allData.trend3
    ];

    const video =
        allVideos.find(v => {

            return (
                v.id == videoId
            );

        });

    if (!video) return;

    document.getElementById(
        'videoTitle'
    ).innerText =
        video.title;

    document.getElementById(
        'videoImage'
    ).src =
        video.image;

    document.getElementById(
        'videoMeta'
    ).innerText =

        `${video.level} • ${video.words} Words`;

    document.getElementById(
        'videoDescription'
    ).innerText =

        video.description ||
        'Learn English with real videos.';
  
    document.getElementById(
        'backButton'
    ).addEventListener(
        'click',
        () => {

            loadExplorePage();

        }
    );
    
    await renderDialogue(video);

    document.getElementById(
        'playButton'
    ).addEventListener(
        'click',
        () => {

            openPlayPage(video.id);

        }
    );
}

async function renderDialogue(
    video
) {

    const container =
        document.getElementById(
            'videoDialogue'
        );

    if (!video.subtitles) {

        container.innerHTML = `

            <div class="empty-message">

                No subtitles available.

            </div>

        `;

        return;
    }

    const response =
        await fetch(`/api/videos/${video.id}/subtitles/`);

    const subtitles =
        await response.json();

    renderVocabulary(
        subtitles
    );

    container.innerHTML = '';

    subtitles.forEach(subtitle => {

        container.innerHTML += `

            <div class="dialogue-line">

                <button
                    class="dialogue-audio"
                    data-start="${subtitle.start}"
                >
                    🔊
                </button>

                <span>
                    ${subtitle.text}
                </span>

            </div>

        `;

    });

}

function renderVocabulary(
    subtitles
) {

    const container =
        document.getElementById(
            'videoVocabulary'
        );

    const uniqueWords =
        new Set();

    subtitles.forEach(subtitle => {

        subtitle.text
            .split(' ')
            .forEach(word => {

                const cleanWord =

                    word
                        .toLowerCase()
                        .trim()
                        .replace(/[.,!?;:]/g, '');

                if (
                    cleanWord.length > 2
                ) {

                    uniqueWords.add(
                        cleanWord
                    );

                }

            });

    });

    let html = '';

    uniqueWords.forEach(word => {

        const vocab =
            vocabularyData[word];

        if (!vocab) return;

        html += `

            <div class="vocab-row">

                <div class="vocab-word">
                    ${word}
                </div>

                <div class="vocab-ipa">
                    ${vocab.ipa || ''}
                </div>

                <div class="vocab-translation">
                    ${vocab.translation || ''}
                </div>

                <div class="vocab-definition">
                    ${vocab.definition || ''}
                </div>

            </div>

        `;

    });

    container.innerHTML = html;

}

async function loadPlayPage() {

    const response = await fetch('/play/');

    const html =
        await response.text();

    document.getElementById(
        'mainContent'
    ).innerHTML = html;

}

async function openPlayPage(
    videoId
) {

    await loadPlayPage();

    const allVideos = [

        ...allData.recentVideos,

        ...allData.trendingVideos,

        ...allData.trend3
    ];

    const video =
        allVideos.find(v => {

            return (
                v.id == videoId
            );

        });

    if (!video) return;

    document.getElementById(
        'playTitle'
    ).innerText =
        video.title;

    setupPlayVideo(video);

    if (
        video.subtitles
    ) {

        renderPlaySubtitles(
            video
        );
    }

    document.getElementById(
        'backToVideo'
    ).addEventListener(
        'click',
        () => {

            openVideoPage(video.id);

        }
    );

}



let currentSubtitles = [];

async function renderPlaySubtitles(
    video
) {

    const container =
        document.getElementById(
            'playSubtitles'
        );

    /* NO SUBTITLES */

    if (!video.subtitles) {

        container.innerHTML = '';

        return;
    }

    const response =
        await fetch(`/api/videos/${video.id}/subtitles/`);

    currentSubtitles =
        await response.json();

    container.innerHTML = `

        <div
            id="activeSubtitle"
            class="active-subtitle"
        >
        </div>

    `;

    startSubtitleSync();

}

let lastSubtitle = '';

function startSubtitleSync() {

    const video =
        document.getElementById(
            'playVideo'
        );

    const subtitleElement =
        document.getElementById(
            'activeSubtitle'
        );

    /* CLICK EVENTS */

    subtitleElement.addEventListener(
        'click',
        (event) => {

            const wordElement =

                event.target.closest(
                    '.subtitle-word'
                );

            if (!wordElement) return;

            /*video.pause();*/

            const word =

                wordElement.innerText

                    .toLowerCase()

                    .replace(/[.,!?]/g, '');

            console.log(
                'Clicked:',
                word
            );

            const rect =

                wordElement.getBoundingClientRect();

            openVocabularyPopup(
                word,
                rect
            );

        }
    );

    /* SYNC */

    video.addEventListener(
        'timeupdate',
        () => {

             if (video.paused) return;
            const currentTime =
                video.currentTime;

            const activeSubtitle =

                currentSubtitles.find(
                    subtitle => {

                        return (

                            currentTime >= subtitle.start &&

                            currentTime <= subtitle.end

                        );

                    }
                );

            if (!activeSubtitle) return;

            /* AVOID RERENDER */

            if (
                lastSubtitle ===
                activeSubtitle.text
            ) {

                return;
            }

            lastSubtitle =
                activeSubtitle.text;

            subtitleElement.innerHTML =

                activeSubtitle.text

                    .split(' ')

                    .map(word => {

                        return `

                            <span
                                class="subtitle-word"
                            >
                                ${word}
                            </span>

                        `;

                    })

                    .join('');

        }
    );

}

