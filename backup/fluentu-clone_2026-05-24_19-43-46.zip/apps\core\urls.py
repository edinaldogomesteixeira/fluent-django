from django.urls import path
from .views import *

urlpatterns = [

    path('', home, name='home'),

    path('explore/', explore_page),

    path('video/', video_page),

    path('play/', play_page),
]