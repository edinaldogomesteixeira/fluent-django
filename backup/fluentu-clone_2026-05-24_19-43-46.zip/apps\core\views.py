from django.shortcuts import render

def home(request):
    return render(request, 'core/home.html')

def explore_page(request):
    return render(request, 'core/explore.html')

def video_page(request):
    return render(request, 'core/video.html')

def play_page(request):
    return render(request, 'core/play.html')