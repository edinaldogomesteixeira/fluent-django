from django.urls import path

from .views import (
    save_progress,
    get_progress
)


urlpatterns = [

    path(

        'api/progress/save/',

        save_progress
    ),
    path(

        'api/progress/<int:video_id>/',

        get_progress
    ),
]