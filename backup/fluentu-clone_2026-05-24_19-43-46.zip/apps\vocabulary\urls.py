from django.urls import path

from .views import vocabulary_detail


urlpatterns = [

    path(

        'api/vocabulary/<str:word>/',

        vocabulary_detail
    ),
]