from django.http import JsonResponse

from apps.vocabulary.models import (
    VocabularyWord
)


def vocabulary_detail(
    request,
    word
):

    normalized = (
        word.lower().strip()
    )

    try:

        vocabulary = (
            VocabularyWord.objects.get(
                normalized_word=normalized
            )
        )

        data = {

            'word':
                vocabulary.word,

            'translation':
                vocabulary.translation,

            'ipa':
                vocabulary.ipa,

            'frequency_rank':
                vocabulary.frequency_rank,
        }

    except VocabularyWord.DoesNotExist:

        data = {

            'word': word,

            'translation': '',

            'ipa': '',
        }

    return JsonResponse(data)