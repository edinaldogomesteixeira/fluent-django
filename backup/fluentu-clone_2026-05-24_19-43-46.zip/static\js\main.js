function renderVideos(videos, containerId) {

    const container =
        document.getElementById(containerId);

    container.innerHTML = '';

    videos.forEach(video => {

        container.innerHTML +=
            createVideoCard(video);

    });
}

function setupSearch() {

    const searchInput =
        document.getElementById('searchInput');

    searchInput.addEventListener('input', () => {

        const value =
            searchInput.value.toLowerCase();

        const filteredRecent =
            allData.recentVideos.filter(video => {

                return video.title
                    .toLowerCase()
                    .includes(value);

            });

        const filteredTrending =
            allData.trendingVideos.filter(video => {

                return video.title
                    .toLowerCase()
                    .includes(value);

            });

        renderVideos(
            filteredRecent,
            'recentVideos'
        );

        renderVideos(
            filteredTrending,
            'trendingVideos'
        );

        /*setupPreviewVideos();*/
        setupVideoClicks();

    });

}


function setupVideoClicks() {

    const cards =
        document.querySelectorAll('.video-card');

    cards.forEach(card => {

        card.addEventListener('click', () => {

            const title =
                card.querySelector('.video-title')
                    .innerText;

            let selectedVideo = null;

            const allVideos = [
                ...allData.recentVideos,
                ...allData.trendingVideos
            ];

            selectedVideo = allVideos.find(video => {

                return video.title === title;

            });

            if (selectedVideo) {
                openVideoPage(
                    selectedVideo.id
                );

            }

        });

    });

}

async function openTopic(section) {

    await loadTopicPage();

    const topicTitle =
        document.getElementById(
            'topicTitle'
        );

    const topicGrid =
        document.getElementById(
            'topicGrid'
        );

    topicTitle.innerText =
        section;

    const videos =
        allData[section];

    topicGrid.innerHTML =
        videos.map(video => {

            return createVideoCard(video);

        }).join('');

    setupVideoClicks();

    document.getElementById(
        'backButton'
    ).addEventListener('click', () => {

        loadExplorePage();

    });

}