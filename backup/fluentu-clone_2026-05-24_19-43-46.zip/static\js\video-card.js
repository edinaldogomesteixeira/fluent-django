function createVideoCard(video) {

    return `
    
        <div class="video-card">

            <div class="thumbnail">

                <img
                    src="${video.image}"
                    alt="${video.title}"
                    class="thumbnail-image"
                >

                <img
                    src="${video.preview}"
                    alt="${video.title}"
                    class="preview-image"
                >

            </div>

            <h3 class="video-title">
                ${video.title}
            </h3>

            <p class="video-info">
                ${video.level} • ${video.words} Words
            </p>

        </div>

    `;
}