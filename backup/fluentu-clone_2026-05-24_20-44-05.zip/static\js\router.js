
let currentVideoId = null;

let lastProgressSave = 0;

let currentSubtitles = [];

let progressReady = false;
let isSeeking = false;

async function loadExplorePage() {

    const response = await fetch('/explore/');

    const html =
        await response.text();

    document.getElementById(
        'mainContent'
    ).innerHTML = html;

    loadVideos();
}

async function loadTopicPage() {

    const response = await fetch('/topic/');

    const html =
        await response.text();

    document.getElementById(
        'mainContent'
    ).innerHTML = html;
}

/* YOUTUBE PLAYER */
function createYouTubePlayer(
    youtubeId
) {

    const youtubeContainer =
        document.getElementById(
            'youtubePlayer'
        );

    if (
        !youtubeContainer
    ) {

        console.error(
            'youtubePlayer container not found'
        );

        return;
    }

    /* DESTROY PREVIOUS */

    if (
        youtubePlayer
    ) {

        youtubePlayer.destroy();
    }

    youtubePlayer = new YT.Player(
        'youtubePlayer',
        {

            height: '500',

            width: '100%',

            videoId: youtubeId,

            playerVars: {

                autoplay: 1,

                controls: 1,

                rel: 0
            }
        }
    );
}

document.addEventListener(
    'click',
    async (event) => {

        const link =
            event.target.closest('a');

        if (!link) return;

        const href =
            link.getAttribute('href');

        if (!href) return;

        /* TOPIC */

        if (
            href.includes('topic.html')
        ) {

            event.preventDefault();

            const url =
                new URL(
                    href,
                    window.location.origin
                );

            const section =
                url.searchParams.get(
                    'section'
                );

            await openTopic(section);
        }

    }
);

function setupPlayVideo(video) {

    const videoElement =
        document.getElementById(
            'playVideo'
        );

    const youtubeContainer =
        document.getElementById(
            'youtubePlayer'
        );

    /* RESET */

    videoElement.pause();

    videoElement.removeAttribute(
        'src'
    );

    //videoElement.load();

    videoElement.style.display =
        'none';

    youtubeContainer.style.display =
        'none';

    console.log(video);

    /* YOUTUBE */

    if (
        video.provider === 'youtube'
    ) {

        youtubeContainer.style.display =
            'block';

        createYouTubePlayer(
            video.youtubeId
        );

        return null;
    }

    /* GET VIDEO URL */

    let videoUrl = null;

    if (

        video.video &&

        video.video !== 'null' &&

        video.video !== 'undefined'

    ) {

        videoUrl = video.video;
    }

    else if (

        video.hls &&

        video.hls !== 'null' &&

        video.hls !== 'undefined'

    ) {

        videoUrl = video.hls;
    }

    /* INVALID */

    if (!videoUrl) {

        console.error(
            'No valid video source'
        );

        return null;
    }

    console.log(
        'VIDEO URL:',
        videoUrl
    );

    /* SHOW PLAYER */

    videoElement.style.display =
        'block';

    if (
        video.provider === 'local'
    ) {

        videoElement.src =

            `/stream/${video.id}/`;
    }

    else {

        videoElement.src =
            videoUrl;
    }

    videoElement.load();

    return videoElement;
}

window.addEventListener(
    'DOMContentLoaded',
    async () => {
        
        
        
        initModalController();
        await loadVocabulary();
        
        await loadExplorePage();
    }
);

async function loadVideoPage() {

    const response =
        await fetch('/video/');

    const html =
        await response.text();

    document.getElementById(
        'mainContent'
    ).innerHTML = html;

}

async function openVideoPage(
    videoId
) {

    await loadVideoPage();

    const allVideos = [

        ...allData.recentVideos,

        ...allData.trendingVideos,

        ...allData.trend3
    ];

    const video =
        allVideos.find(v => {

            return (
                v.id == videoId
            );

        });

    if (!video) return;

    document.getElementById(
        'videoTitle'
    ).innerText =
        video.title;

    document.getElementById(
        'videoImage'
    ).src =
        video.image;

    document.getElementById(
        'videoMeta'
    ).innerText =

        `${video.level} • ${video.words} Words`;

    document.getElementById(
        'videoDescription'
    ).innerText =

        video.description ||
        'Learn English with real videos.';
  
    document.getElementById(
        'backButton'
    ).addEventListener(
        'click',
        () => {

            loadExplorePage();

        }
    );
    
    await renderDialogue(video);

    document.getElementById(
        'playButton'
    ).addEventListener(
        'click',
        () => {

            openPlayPage(video);

        }
    );
}

async function renderDialogue(
    video
) {

    const container =
        document.getElementById(
            'videoDialogue'
        );

    if (!video.subtitles) {

        container.innerHTML = `

            <div class="empty-message">

                No subtitles available.

            </div>

        `;

        return;
    }

    const response =
        await fetch(`/api/videos/${video.id}/subtitles/`);

    const subtitles =
        await response.json();

    renderVocabulary(
        subtitles
    );

    container.innerHTML = '';

    subtitles.forEach(subtitle => {

        container.innerHTML += `

            <div class="dialogue-line">

                <button
                    class="dialogue-audio"
                    data-start="${subtitle.start}"
                >
                    🔊
                </button>

                <span>
                    ${subtitle.text}
                </span>

            </div>

        `;

    });

}

function renderVocabulary(
    subtitles
) {

    const container =
        document.getElementById(
            'videoVocabulary'
        );

    const uniqueWords =
        new Set();

    subtitles.forEach(subtitle => {

        subtitle.text
            .split(' ')
            .forEach(word => {

                const cleanWord =

                    word
                        .toLowerCase()
                        .trim()
                        .replace(/[.,!?;:]/g, '');

                if (
                    cleanWord.length > 2
                ) {

                    uniqueWords.add(
                        cleanWord
                    );

                }

            });

    });

    let html = '';

    uniqueWords.forEach(word => {

        const vocab =
            vocabularyData[word];

        if (!vocab) return;

        html += `

            <div class="vocab-row">

                <div class="vocab-word">
                    ${word}
                </div>

                <div class="vocab-ipa">
                    ${vocab.ipa || ''}
                </div>

                <div class="vocab-translation">
                    ${vocab.translation || ''}
                </div>

                <div class="vocab-definition">
                    ${vocab.definition || ''}
                </div>

            </div>

        `;

    });

    container.innerHTML = html;

}

async function loadPlayPage() {

    const response = await fetch('/play/');

    const html =
        await response.text();

    document.getElementById(
        'mainContent'
    ).innerHTML = html;

}

async function openPlayPage(
    video
) {

    console.log(
        'OPEN PLAY PAGE VIDEO:',
        video
    );

    await loadPlayPage();

    if (!video) return;

    currentVideoId = video.id;

    progressReady = false;
    lastProgressSave = -1;

    console.log(
        'CURRENT VIDEO ID:',
        currentVideoId
    );

    document.getElementById(
        'playTitle'
    ).innerText =
        video.title;
    

    /* LOAD SAVED PROGRESS */
    
    const progress =
        await loadProgress(
            video.id
        );

    /* SETUP PLAYER */

    const videoElement =
        setupPlayVideo(video);

    if (!videoElement) return;

    setupProgressTracking(
        videoElement
    );

    /* RESUME PLAYBACK */

    if (
        progress.current_seconds > 0
    ) {

        const applyProgress = () => {

            if (

                !videoElement.duration ||

                isNaN(videoElement.duration)

            ) {

                setTimeout(
                    applyProgress,
                    300
                );

                return;
            }

            const safeTime = Math.min(

                progress.current_seconds,

                videoElement.duration - 1
            );

            console.log(
                'Resume playback:',
                safeTime
            );

            videoElement.currentTime =
                safeTime;

            setTimeout(() => {

                progressReady = true;

            }, 1500);
        };

        applyProgress();

    }

    else {

        setTimeout(() => {

            progressReady = true;

        }, 2000);
    }

    /* SUBTITLES */

    if (
        video.subtitles
    ) {

        renderPlaySubtitles(
            video
        );
    }

    /* BACK BUTTON */

    document.getElementById(
        'backToVideo'
    ).addEventListener(
        'click',
        () => {

            openVideoPage(video.id);

        }
    );
}

async function saveProgress(
    videoId,
    currentSeconds,
    durationSeconds
) {
    console.log({

        videoId,

        currentSeconds,

        durationSeconds
    });

    const progressPercent =

        durationSeconds > 0

            ? (

                currentSeconds /
                durationSeconds

            ) * 100

            : 0;

    try {

        await fetch(

            '/api/progress/save/',

            {

                method: 'POST',

                headers: {

                    'Content-Type':
                        'application/json',
                },

                body: JSON.stringify({

                    user_id: 1,

                    video_id: videoId,

                    current_seconds:
                        currentSeconds,

                    duration_seconds:
                        durationSeconds,

                    progress_percent:
                        progressPercent,
                })
            }
        );

    } catch (error) {

        console.error(
            'Progress save error:',
            error
        );
    }
}

async function renderPlaySubtitles(
    video
) {

    const container =
        document.getElementById(
            'playSubtitles'
        );

    /* NO SUBTITLES */

    if (!video.subtitles) {

        container.innerHTML = '';

        return;
    }

    const response =
        await fetch(`/api/videos/${video.id}/subtitles/`);

    currentSubtitles =
        await response.json();

    container.innerHTML = `

        <div
            id="activeSubtitle"
            class="active-subtitle"
        >
        </div>

    `;

    startSubtitleSync();

}

let lastSubtitle = '';

function startSubtitleSync() {

    const video =
        document.getElementById(
            'playVideo'
        );

    const subtitleElement =
        document.getElementById(
            'activeSubtitle'
        );

    /* CLICK EVENTS */

    subtitleElement.addEventListener(
        'click',
        (event) => {

            const wordElement =

                event.target.closest(
                    '.subtitle-word'
                );

            if (!wordElement) return;

            const word =

                wordElement.innerText

                    .toLowerCase()

                    .replace(/[.,!?]/g, '');

            const rect =

                wordElement.getBoundingClientRect();

            openVocabularyPopup(
                word,
                rect
            );

        }
    );

    /* SYNC */

    video.addEventListener(
        'timeupdate',
        () => {

                if (

                    video.paused ||

                    isSeeking

                ) return;

            const currentTime =
                video.currentTime;

            const activeSubtitle =

                currentSubtitles.find(
                    subtitle => {

                        return (

                            currentTime >= subtitle.start &&

                            currentTime <= subtitle.end

                        );

                    }
                );

            if (!activeSubtitle) return;

            /* AVOID RERENDER */

            if (
                lastSubtitle ===
                activeSubtitle.text
            ) {

                return;
            }

            lastSubtitle =
                activeSubtitle.text;

            subtitleElement.innerHTML =

                activeSubtitle.text

                    .split(' ')

                    .map(word => {

                        return `

                            <span
                                class="subtitle-word"
                            >
                                ${word}
                            </span>

                        `;

                    })

                    .join('');
        }
    );
}

async function loadProgress(
    videoId
) {

    try {

        const response =
            await fetch(

                `/api/progress/${videoId}/`
            );

        return await response.json();

    } catch (error) {

        console.error(
            'Progress load error:',
            error
        );

        return {

            current_seconds: 0
        };
    }
}

function setupProgressTracking(
    videoElement
) {

    videoElement.addEventListener(
        'seeking',
        () => {

            isSeeking = true;
        }
    );

    videoElement.addEventListener(
        'seeked',
        () => {

            setTimeout(() => {

                isSeeking = false;

            }, 300);
        }
    );

    videoElement.addEventListener(
        'timeupdate',
        () => {

                if (

                    videoElement.paused ||

                    !progressReady ||

                    isSeeking

                ) return;

            const currentTime =
                videoElement.currentTime;

            if (

                Math.floor(currentTime) % 10 === 0 &&

                Math.floor(currentTime) !==
                lastProgressSave

            ) {

                lastProgressSave =
                    Math.floor(currentTime);

                saveProgress(

                    currentVideoId,

                    currentTime,

                    videoElement.duration
                );
            }

        }
    );
}