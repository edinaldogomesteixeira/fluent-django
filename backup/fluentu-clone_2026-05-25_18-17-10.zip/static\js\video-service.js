let allData = {};

async function loadVideos() {

    const response =
        await fetch(

            '/api/videos/',

            {

                credentials: 'same-origin'
            }
        );

    const data =
        await response.json();

    allData = {

        recentVideos: data,

        trendingVideos: data,

        trend3: data
    };

    renderVideos(
        allData.recentVideos,
        'recentVideos'
    );

    renderVideos(
        allData.trendingVideos,
        'trendingVideos'
    );

    setupSearch();

    /*setupPreviewVideos();*/

    setupVideoClicks();

    loadVocabulary();
}