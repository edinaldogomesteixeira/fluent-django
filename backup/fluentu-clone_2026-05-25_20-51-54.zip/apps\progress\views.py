import json

from django.http import JsonResponse

from django.views.decorators.csrf import csrf_exempt

from django.contrib.auth.models import User

from apps.videos.models import Video

from .models import WatchProgress

from django.contrib.auth.decorators import (
    login_required
)


@csrf_exempt
@login_required
def save_progress(request):

    if request.method != 'POST':

        return JsonResponse({

            'error': 'POST required'
        }, status=400)

    data = json.loads(
        request.body
    )

    user_id = data.get('user_id')

    video_id = data.get('video_id')

    current_seconds = data.get(
        'current_seconds',
        0
    )

    duration_seconds = data.get(
        'duration_seconds',
        0
    )

    progress_percent = data.get(
        'progress_percent',
        0
    )

    video = Video.objects.get(
        id=video_id
    )

    progress, created = (
        WatchProgress.objects.get_or_create(

            user=request.user,

            video=video
        )
    )

    progress.current_seconds = (
        current_seconds
    )

    progress.duration_seconds = (
        duration_seconds
    )

    progress.progress_percent = (
        progress_percent
    )

    if progress_percent >= 90:

        progress.is_completed = True

    progress.save()

    return JsonResponse({

        'success': True
    })

def get_progress(
    request,
    video_id
):

    user = User.objects.get(
        id=1
    )

    try:

        progress = (
            WatchProgress.objects.get(

                user=user,

                video_id=video_id
            )
        )

        data = {

            'current_seconds':

                progress.current_seconds,

            'progress_percent':

                progress.progress_percent,
        }

    except WatchProgress.DoesNotExist:

        data = {

            'current_seconds': 0,

            'progress_percent': 0,
        }

    return JsonResponse(data)