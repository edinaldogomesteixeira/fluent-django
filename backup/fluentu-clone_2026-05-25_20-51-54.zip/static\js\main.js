function renderVideos(videos, containerId) {

    const container =
        document.getElementById(containerId);

    container.innerHTML = '';

    videos.forEach(video => {

        container.innerHTML +=
            createVideoCard(video);

    });
}

function renderDynamicCategories() {

    const container =

        document.getElementById(
            'dynamicCategories'
        );

    container.innerHTML = '';

    Object.entries(

        allData.categories

    ).forEach(([slug, categoryData]) => {

        const videos = categoryData.videos;
        const categoryName = categoryData.name;

        container.innerHTML += `

            <div class="category">

                <div class="category-header">

                    <h2 class="category-title">

                        ${categoryName}

                    </h2>

                    <a
                        class="see-all"
                        href="topic.html?section=${slug}"
                    >
                        See All
                    </a>

                </div>

                <div
                    class="video-row"
                    id="${slug}"
                ></div>

            </div>

        `;

        renderVideos(
            videos,
            slug
        );

    });

}

/*function setupSearch() {

    const searchInput =
        document.getElementById('searchInput');

    searchInput.addEventListener('input', () => {

        const value =
            searchInput.value.toLowerCase();

        const filteredRecent =
            allData.recentVideos.filter(video => {

                return video.title
                    .toLowerCase()
                    .includes(value);

            });

        const filteredTrending =
            allData.trendingVideos.filter(video => {

                return video.title
                    .toLowerCase()
                    .includes(value);

            });

        renderVideos(
            filteredRecent,
            'recentVideos'
        );

        renderVideos(
            filteredTrending,
            'trendingVideos'
        );

        setupVideoClicks();

    });

}
*/


function setupVideoClicks() {

    document.addEventListener(
        'click',
        (event) => {

            const card =

                event.target.closest(
                    '.video-card'
                );

            if (!card) return;

            const videoId =

                card.dataset.videoId;

            if (!videoId) return;

            openVideoPage(videoId);

        }
    );
}


async function openTopic(section) {

    await loadTopicPage();

    const topicTitle =
        document.getElementById(
            'topicTitle'
        );

    const topicGrid =
        document.getElementById(
            'topicGrid'
        );

    topicTitle.innerText =
        section;

    const videos =
        allData.categories[section];

    topicGrid.innerHTML =
        videos.map(video => {

            return createVideoCard(video);

        }).join('');

    setupVideoClicks();

    document.getElementById(
        'backButton'
    ).addEventListener('click', () => {

        loadExplorePage();

    });

}